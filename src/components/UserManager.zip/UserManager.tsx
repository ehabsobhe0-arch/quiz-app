// UserManager.tsx - الإصلاح الكامل
import React, { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Upload, User, LogIn, Loader, Camera } from "lucide-react";

interface RegistrationProps {
  deviceFingerprint: string;
  ipAddress: string;
}

export default function Registration({ deviceFingerprint, ipAddress }: RegistrationProps) {
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const registerUser = useMutation(api.users.registerUser);
  const generateUploadUrl = useMutation(api.users.generateUploadUrl);
  
  // التصحيح: استخدم useQuery بدلاً من useMutation
  const existingUser = useQuery(api.users.findUserByName, 
    name.trim() ? { name: name.trim() } : "skip"
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("يرجى إدخال الاسم");
      return;
    }

    if (name.trim().length < 2) {
      toast.error("الاسم يجب أن يكون على الأقل حرفين");
      return;
    }

    // التحقق من الاسم قبل التسجيل
    if (existingUser) {
      toast.error("هذا الاسم مستخدم بالفعل. يرجى اختيار اسم آخر");
      return;
    }

    setIsLoading(true);
    try {
      let avatarId = undefined;

      if (avatar) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": avatar.type },
          body: avatar,
        });

        if (result.ok) {
          const { storageId } = await result.json();
          avatarId = storageId;
        }
      }

      await registerUser({
        name: name.trim(),
        deviceFingerprint,
        ipAddress,
        avatar: avatarId,
      });

      toast.success("تم التسجيل بنجاح!");
      
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء التسجيل");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (file && file.size > 2 * 1024 * 1024) {
      toast.error("حجم الصورة يجب أن يكون أقل من 2MB");
      return;
    }
    setAvatar(file);
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-3 relative"
      style={{
        backgroundImage: "url('/images/background.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        fontFamily: "'Cairo', 'Noto Sans Arabic', sans-serif"
      }}
    >
      <div
        className="absolute inset-0"
        style={{ background: "rgba(6, 30, 63, 0.45)" }}
      />

      <div className="relative w-full max-w-sm mx-auto z-10">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-2xl p-4 sm:p-6 border border-white/30 transform transition-all duration-300 hover:shadow-3xl">
          <div className="flex flex-col items-center">
            <div className="rounded-full p-1 bg-gradient-to-r from-sky-400 via-indigo-500 to-purple-600 shadow-xl transform transition-all duration-300 hover:scale-105">
              <div className="bg-white rounded-full p-1">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full overflow-hidden">
                  <img
                    src="/images/logo.png"
                    alt="شعار الاجتماع"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>

            <h1 className="mt-3 text-lg sm:text-xl font-extrabold text-slate-900">مسابقات الكنيسة</h1>
            <p className="text-xs text-slate-700 mt-1">مرحباً بك! سجّل اسمك للمشاركة</p>
          </div>

          <form onSubmit={handleSubmit} className="mt-4 space-y-3">
            <div>
              <label className="block text-xs sm:text-sm font-medium text-slate-800 mb-1 flex items-center gap-1">
                <User className="w-3 h-3 sm:w-4 sm:h-4" />
                الاسم *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 sm:px-4 sm:py-2 rounded-lg border border-slate-200 shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-300 transition text-sm"
                placeholder="أدخل اسمك"
                required
                maxLength={50}
                minLength={2}
              />
              <p className="text-xs text-slate-500 mt-1">الحد الأقصى 50 حرف - الأدنى حرفين</p>
            </div>

            <div>
              <label className="block text-xs sm:text-sm font-medium text-slate-800 mb-1 flex items-center gap-1">
                <Camera className="w-3 h-3 sm:w-4 sm:h-4" />
                الصورة الشخصية (اختيارية)
              </label>
              <div className="flex items-center gap-2">
                <label
                  htmlFor="avatar"
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-sky-500 hover:bg-sky-600 text-white text-xs cursor-pointer select-none shadow transition-all duration-200 hover:shadow-md"
                >
                  <Upload className="w-3 h-3" />
                  اختر صورة
                </label>
                <input 
                  id="avatar" 
                  type="file" 
                  accept="image/*" 
                  onChange={handleFileChange} 
                  className="hidden" 
                />

                <div className="flex-1 text-xs text-slate-600">
                  {avatar ? (
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full overflow-hidden border border-slate-200 shadow-sm">
                        <img src={URL.createObjectURL(avatar)} alt="preview" className="w-full h-full object-cover" />
                      </div>
                      <div className="truncate max-w-[100px] sm:max-w-[120px]">{avatar.name}</div>
                    </div>
                  ) : (
                    <div className="text-slate-500">لم يتم اختيار صورة</div>
                  )}
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-1">الحجم الأقصى 2MB</p>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-1 inline-flex items-center justify-center gap-1 sm:gap-2 rounded-lg py-2 sm:py-3 bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-semibold shadow hover:from-sky-600 hover:to-indigo-700 disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-300 hover:shadow-lg text-sm"
            >
              {isLoading ? (
                <>
                  <Loader className="animate-spin h-4 w-4" />
                  جاري التسجيل...
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  تسجيل
                </>
              )}
            </button>
          </form>

          <p className="mt-3 text-center text-xs text-slate-700 border-t border-slate-200 pt-3">يُسمح بحساب واحد فقط لكل جهاز</p>
        </div>

        <div className="mt-3 text-center">
          <div className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/10 text-white/80 text-xs backdrop-blur-sm border border-white/20">
            <span>نظام المسابقات المسيحية</span>
          </div>
        </div>
      </div>

      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
          @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@400;600;700&display=swap');
          
          .shadow-3xl {
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
          }
        `}
      </style>
    </div>
  );
}