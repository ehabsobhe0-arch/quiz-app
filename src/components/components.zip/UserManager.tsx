import React from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

interface User {
  _id: string;
  name: string;
  deviceFingerprint: string;
  isAdmin: boolean;
  isModerator: boolean;
}

interface UserManagerProps {
  user: User;
}

export default function UserManager({ user }: UserManagerProps) {
  const users = useQuery(api.users.getAllUsers) || [];
  const makeUserModerator = useMutation(api.users.makeUserModerator);
  const deleteUser = useMutation(api.users.deleteUser);

  const handleMakeModerator = async (userId: Id<"users">) => {
    try {
      await makeUserModerator({
        userId,
        currentUserFingerprint: user.deviceFingerprint,
      });
      toast.success("تم تعيين المستخدم كمشرف");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء تعيين المشرف");
    }
  };

  const handleDeleteUser = async (userId: Id<"users">, userName: string) => {
    if (!confirm(`هل أنت متأكد من حذف المستخدم "${userName}"؟`)) {
      return;
    }

    try {
      await deleteUser({
        userId,
        currentUserFingerprint: user.deviceFingerprint,
      });
      toast.success("تم حذف المستخدم");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء حذف المستخدم");
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-dark-blue">إدارة المستخدمين</h2>
        <div className="text-sm text-gray-600 bg-blue-50 px-3 py-1 rounded-lg">
          إجمالي المستخدمين: <span className="font-semibold text-dark-blue">{users.length}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {users.map((u) => (
          <div key={u._id} className="bg-white rounded-xl shadow-lg p-4 border border-gold/20">
            <div className="flex items-center space-x-4 space-x-reverse mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-dark-blue to-blue-800 flex items-center justify-center shadow-md">
                {u.avatarUrl ? (
                  <img src={u.avatarUrl} alt={u.name} className="w-full h-full rounded-full object-cover" />
                ) : (
                  <span className="text-white font-semibold text-base">
                    {u.name.charAt(0)}
                  </span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-base text-dark-blue truncate">{u.name}</h3>
                <div className="flex items-center space-x-2 space-x-reverse mt-2">
                  {u.isAdmin && (
                    <span className="bg-red-100 text-red-800 text-xs font-semibold px-2 py-1 rounded-lg border border-red-200">
                      مدير
                    </span>
                  )}
                  {u.isModerator && (
                    <span className="bg-blue-100 text-dark-blue text-xs font-semibold px-2 py-1 rounded-lg border border-blue-200">
                      مشرف
                    </span>
                  )}
                  {!u.isAdmin && !u.isModerator && (
                    <span className="bg-gray-100 text-gray-700 text-xs font-semibold px-2 py-1 rounded-lg border border-gray-200">
                      عضو
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="text-sm text-gray-600 mb-4 bg-gray-50 p-2 rounded-lg">
              <p>تاريخ التسجيل: {new Date(u.createdAt).toLocaleDateString('ar-EG')}</p>
            </div>

            {user.isAdmin && u._id !== user._id && (
              <div className="flex space-x-3 space-x-reverse">
                {!u.isModerator && !u.isAdmin && (
                  <button
                    onClick={() => handleMakeModerator(u._id)}
                    className="flex-1 bg-gradient-to-r from-dark-blue to-blue-800 text-white py-2 px-3 rounded-lg text-sm font-semibold hover:from-blue-800 hover:to-dark-blue transition-all shadow-md"
                  >
                    تعيين مشرف
                  </button>
                )}
                
                <button
                  onClick={() => handleDeleteUser(u._id, u.name)}
                  className="bg-red-500 text-white py-2 px-3 rounded-lg text-sm font-semibold hover:bg-red-600 transition-all shadow-md"
                >
                  حذف
                </button>
              </div>
            )}

            {u._id === user._id && (
              <div className="text-center text-sm text-blue-600 bg-blue-50 p-2 rounded-lg border border-blue-200">
                هذا الحساب الخاص بك
              </div>
            )}
          </div>
        ))}
      </div>

      {users.length === 0 && (
        <div className="text-center py-12 bg-white rounded-xl shadow-lg p-8 border border-gold/20">
          <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-200">
            <svg className="w-8 h-8 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-dark-blue mb-2">لا يوجد مستخدمون</h3>
          <p className="text-base text-gray-600">لم يتم تسجيل أي مستخدمين بعد</p>
        </div>
      )}

      {/* إضافة ستايل مخصص للألوان */}
      <style jsx>{`
        .bg-dark-blue {
          background-color: #1a365d;
        }
        .text-dark-blue {
          color: #1a365d;
        }
        .text-gold {
          color: #d4af37;
        }
        .bg-gold {
          background-color: #d4af37;
        }
        .border-gold {
          border-color: #d4af37;
        }
      `}</style>
    </div>
  );
}