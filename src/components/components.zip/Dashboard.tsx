import React from "react";
import { Id } from "../../convex/_generated/dataModel";
import { Timer, CheckCircle, Shield } from "lucide-react";

interface User {
  _id: string;
  name: string;
  avatarUrl?: string | null;
  isAdmin: boolean;
  isModerator: boolean;
}

interface Quiz {
  _id: Id<"quizzes">;
  title: string;
  description?: string;
  imageUrl?: string | null;
  questionCount: number;
  isActive: boolean;
}

interface DashboardProps {
  user: User;
  activeQuiz: Quiz | null;
  onStartQuiz: (quizId: Id<"quizzes">) => void;
  onViewLeaderboard: () => void;
  onOpenAdmin: () => void;
}

export default function Dashboard({
  user,
  activeQuiz,
  onStartQuiz,
  onViewLeaderboard,
  onOpenAdmin,
}: DashboardProps) {
  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6 font-[Cairo]">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-indigo-700 flex items-center justify-center text-white font-bold text-xl shadow">
              {user.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                user.name.charAt(0)
              )}
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-gray-900">
                مرحباً، {user.name}
              </h1>
              <p className="text-sm text-gray-500">
                {user.isAdmin ? "مدير" : user.isModerator ? "مشرف" : "عضو"}
              </p>
            </div>
          </div>

          {(user.isAdmin || user.isModerator) && (
            <button
              onClick={onOpenAdmin}
              className="px-5 py-2 rounded-lg font-semibold bg-indigo-700 text-white text-sm hover:bg-indigo-800 transition"
            >
              لوحة الإدارة
            </button>
          )}
        </div>

        {/* Active Quiz */}
        {activeQuiz ? (
          <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition">
            {activeQuiz.imageUrl && (
              <img
                src={activeQuiz.imageUrl}
                alt={activeQuiz.title}
                className="w-full h-40 sm:h-56 object-cover"
              />
            )}
            <div className="p-4 sm:p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-2">
                {activeQuiz.title}
              </h2>
              {activeQuiz.description && (
                <p className="text-sm text-gray-600 mb-4">
                  {activeQuiz.description}
                </p>
              )}
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => onStartQuiz(activeQuiz._id)}
                  className="flex-1 bg-green-600 text-white py-2 rounded-lg font-semibold hover:bg-green-700 transition"
                >
                  ابدأ المسابقة
                </button>
                <button
                  onClick={onViewLeaderboard}
                  className="flex-1 bg-indigo-700 text-white py-2 rounded-lg font-semibold hover:bg-indigo-800 transition"
                >
                  لوحة المتصدرين
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-md p-6 text-center">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              لا توجد مسابقة نشطة
            </h3>
            <p className="text-sm text-gray-600">
              انتظر حتى يقوم المشرف ببدء مسابقة جديدة
            </p>
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            {
              title: "سرعة الإجابة",
              desc: "10 نقاط للإجابة السريعة",
              icon: <Timer className="w-5 h-5 text-blue-600" />,
            },
            {
              title: "دقة الإجابة",
              desc: "نقاط إضافية للإجابات الصحيحة",
              icon: <CheckCircle className="w-5 h-5 text-green-600" />,
            },
            {
              title: "عدالة المنافسة",
              desc: "حساب واحد لكل جهاز",
              icon: <Shield className="w-5 h-5 text-yellow-600" />,
            },
          ].map((stat, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl shadow-sm p-4 sm:p-6 text-center hover:shadow-md hover:scale-[1.01] transition"
            >
              <div className="flex justify-center mb-2">{stat.icon}</div>
              <h3 className="text-md font-semibold text-gray-900 mb-1">
                {stat.title}
              </h3>
              <p className="text-sm text-gray-600">{stat.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
