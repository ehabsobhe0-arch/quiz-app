import React, { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";
import { 
  ArrowLeft, 
  Clock, 
  Trophy, 
  Crown, 
  Medal, 
  Award, 
  CheckCircle, 
  XCircle,
  BarChart3,
  RefreshCw,
  User,
  ChevronDown,
  ChevronUp,
  X,
  Star,
  Target,
  Zap,
  Sparkles,
  BookOpen,
  Lightbulb,
  Timer,
  Rocket,
  TrendingUp,
  Aperture,
  Gem,
  Heart,
  Flame,
  LightningBolt,
  Shield
} from "lucide-react";

interface User {
  _id: string;
  name: string;
  deviceFingerprint: string;
}

interface QuizPlayProps {
  quizId: Id<"quizzes">;
  user: User;
  onComplete: () => void;
  onBack: () => void;
}

export default function QuizPlay({ quizId, user, onComplete, onBack }: QuizPlayProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(15);
  const [attemptId, setAttemptId] = useState<Id<"attempts"> | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [questionStartTime, setQuestionStartTime] = useState(Date.now());
  const [score, setScore] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [shuffledOptions, setShuffledOptions] = useState<{text: string, originalIndex: number}[]>([]);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [lastUpdated, setLastUpdated] = useState(Date.now());
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [answeredQuestions, setAnsweredQuestions] = useState<Set<number>>(new Set());
  const [showAnswerFeedback, setShowAnswerFeedback] = useState<{isCorrect: boolean, points: number} | null>(null);

  const quiz = useQuery(api.quizzes.getActiveQuiz);
  const questions = useQuery(api.questions.getQuizQuestions, 
    quiz ? { quizId: quiz._id, shuffle: quiz.shuffleQuestions } : "skip"
  ) || [];
  const userAttempts = useQuery(api.attempts.getUserAttempts, {
    quizId,
    userFingerprint: user.deviceFingerprint,
  }) || [];
  
  // جلب بيانات المتصدرين
  const leaderboard = useQuery(api.attempts.getLeaderboard, { quizId }) || [];

  const startAttempt = useMutation(api.attempts.startAttempt);
  const submitAnswer = useMutation(api.attempts.submitAnswer);

  // تحديث بيانات المتصدرين كل 5 ثوان
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdated(Date.now());
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  // البحث عن ترتيب المستخدم الحالي
  const userRank = leaderboard.findIndex(entry => entry.userId === user._id) + 1;
  const top3Players = leaderboard.slice(0, 3);
  const userEntry = leaderboard.find(entry => entry.userId === user._id);

  // Initialize attempt
  useEffect(() => {
    if (quiz && !attemptId) {
      startAttempt({
        quizId: quiz._id,
        userFingerprint: user.deviceFingerprint,
      }).then((id) => {
        setAttemptId(id);
      }).catch((error) => {
        toast.error(error.message);
        onBack();
      });
    }
  }, [quiz, attemptId]);

  // عد التنازلي عند بدء المسابقة
  useEffect(() => {
    if (attemptId && questions.length > 0 && countdown === null) {
      setCountdown(3);
      const countdownInterval = setInterval(() => {
        setCountdown(prev => {
          if (prev === 1) {
            clearInterval(countdownInterval);
            return null;
          }
          return prev! - 1;
        });
      }, 1000);
      
      return () => clearInterval(countdownInterval);
    }
  }, [attemptId, questions.length]);

  // Timer - المؤقت الرئيسي
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (timeLeft > 0 && !isSubmitting && countdown === null && !answeredQuestions.has(currentQuestionIndex)) {
      timer = setTimeout(() => {
        setTimeLeft(prevTime => {
          if (prevTime <= 1) {
            // انتهاء الوقت - إرسال الإجابة تلقائياً فقط إذا لم يتم الإجابة بعد
            if (!answeredQuestions.has(currentQuestionIndex)) {
              handleSubmitAnswer(); // إرسال إجابة فارغة عند انتهاء الوقت
            }
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [timeLeft, isSubmitting, countdown, currentQuestionIndex, answeredQuestions]);

  // Reset timer and shuffle options when question changes
  useEffect(() => {
    if (countdown === null && !answeredQuestions.has(currentQuestionIndex)) {
      // تعيين الوقت بناءً على إعدادات المسابقة أو استخدام الوقت الافتراضي
      const questionTimeLimit = questions[currentQuestionIndex]?.timeLimit || 15;
      setTimeLeft(questionTimeLimit);
      setSelectedAnswer(null);
      setQuestionStartTime(Date.now());
      setShowAnswerFeedback(null);
      
      if (questions.length > 0 && currentQuestionIndex < questions.length) {
        const currentQuestion = questions[currentQuestionIndex];
        if (quiz?.shuffleAnswers) {
          // إنشاء مصفوفة من الخيارات مع الاحتفاظ بالمؤشر الأصلي
          const optionsWithIndex = currentQuestion.options.map((text, index) => ({
            text,
            originalIndex: index
          }));
          
          // خلط الخيارات مع الاحتفاظ بالمؤشر الأصلي
          const shuffled = [...optionsWithIndex].sort(() => Math.random() - 0.5);
          setShuffledOptions(shuffled);
        } else {
          // إذا لم يكن هناك خلط، نستخدم المؤشرات الأصلية
          const optionsWithIndex = currentQuestion.options.map((text, index) => ({
            text,
            originalIndex: index
          }));
          setShuffledOptions(optionsWithIndex);
        }
      }
    }
  }, [currentQuestionIndex, questions, quiz, countdown, answeredQuestions]);

  // عرض عد التنازلي
  if (countdown !== null) {
    return (
      <div 
        className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-purple-900 fixed inset-0 z-50"
        style={{ fontFamily: "'Cairo', 'Noto Sans Arabic', sans-serif" }}
      >
        <div className="text-center">
          <div className="relative">
            <div className="text-8xl font-bold text-yellow-400 animate-pulse mb-4" style={{ textShadow: '0 0 10px #ffd166, 0 0 20px #ffd166, 0 0 30px #ffd166' }}>
              {countdown}
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-pink-500 rounded-full opacity-20 blur-xl"></div>
          </div>
          <div className="flex justify-center mb-6">
            <Sparkles className="w-12 h-12 text-pink-500 animate-bounce" />
          </div>
          <p className="text-xl text-white font-semibold animate-pulse">استعد للمسابقة!</p>
        </div>
      </div>
    );
  }

  if (!quiz || !attemptId || questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-gray-900 to-blue-900">
        <div className="text-center">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-400 mx-auto mb-4"></div>
            <div className="absolute inset-0 bg-blue-500 rounded-full opacity-20 animate-ping"></div>
          </div>
          <p className="text-gray-200">جاري تحميل المسابقة...</p>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  // Check if user has exceeded max attempts
  if (userAttempts.length >= quiz.maxAttempts) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-gray-900 to-blue-900">
        <div className="bg-gray-800 bg-opacity-80 backdrop-blur-md rounded-2xl shadow-2xl p-8 w-full max-w-md text-center border border-purple-500 border-opacity-30">
          <div className="w-20 h-20 bg-red-900 rounded-full flex items-center justify-center mx-auto mb-6 border border-red-700">
            <XCircle className="w-10 h-10 text-red-500" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">انتهت المحاولات</h2>
          <p className="text-gray-300 mb-6">
            لقد استنفدت عدد المحاولات المسموحة ({quiz.maxAttempts})
          </p>
          <button
            onClick={onBack}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3 px-6 rounded-xl font-bold transition-all duration-300 shadow-lg hover:shadow-purple-500/30"
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  const handleSubmitAnswer = async (selectedOption: number = -1) => {
    if (isSubmitting || answeredQuestions.has(currentQuestionIndex)) return;
    
    setIsSubmitting(true);
    
    // وضع علامة على السؤال بأنه تمت الإجابة عليه
    setAnsweredQuestions(prev => new Set(prev).add(currentQuestionIndex));
    setSelectedAnswer(selectedOption !== -1 ? selectedOption : null);
    
    const timeSpent = Date.now() - questionStartTime;

    try {
      const result = await submitAnswer({
        attemptId,
        questionId: currentQuestion._id,
        selectedAnswer: selectedOption,
        timeSpent,
      });

      if (result.isCorrect) {
        setCorrectAnswers(prev => prev + 1);
        // حساب النقاط بناءً على الوقت المتبقي (كلما كان الوقت المتبقي أكثر، النقاط أكثر)
        const pointsEarned = Math.max(1, Math.floor((timeLeft / 15) * 10));
        setScore(prev => prev + pointsEarned);
        
        // عرض ملاحظة بالإجابة الصحيحة
        setShowAnswerFeedback({ isCorrect: true, points: pointsEarned });
      } else {
        setShowAnswerFeedback({ isCorrect: false, points: 0 });
      }

      // الانتقال للسؤال التالي بعد تأخير قصير
      setTimeout(() => {
        if (currentQuestionIndex < questions.length - 1) {
          setCurrentQuestionIndex(prev => prev + 1);
        } else {
          // Quiz completed
          toast.success("تم إنهاء المسابقة!");
          setTimeout(() => {
            onComplete();
          }, 500);
        }
        setIsSubmitting(false);
      }, 1500);
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إرسال الإجابة");
      setIsSubmitting(false);
    }
  };

  const handleAnswerSelect = (originalIndex: number) => {
    if (isSubmitting || answeredQuestions.has(currentQuestionIndex)) return;
    
    // إرسال الإجابة فوراً بعد الاختيار
    handleSubmitAnswer(originalIndex);
  };

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-gray-900 to-blue-900"
      style={{ fontFamily: "'Cairo', 'Noto Sans Arabic', sans-serif" }}
    >
      {/* شريط الترتيب المباشر للجوال - في الأعلى */}
      <div className="lg:hidden bg-gray-800 bg-opacity-80 backdrop-blur-md shadow-2xl border-b border-purple-500 border-opacity-30">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold shadow-lg">
                {userRank > 0 ? userRank : '--'}
              </div>
              <div>
                <div className="text-xs text-gray-300">ترتيبك</div>
                <div className="text-sm font-bold text-white flex items-center gap-1">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  {score} نقطة
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {top3Players.length > 0 && top3Players.slice(0, 2).map((player, index) => (
                <div key={player._id} className="flex items-center gap-2">
                  <div className="text-yellow-400">
                    {index === 0 ? <Crown className="w-5 h-5" /> : <Star className="w-4 h-4" />}
                  </div>
                  <div className="text-xs font-medium bg-blue-900 bg-opacity-50 px-2 py-1 rounded-lg text-white">{player.score}</div>
                </div>
              ))}
            </div>
            
            <button
              onClick={() => setShowLeaderboard(!showLeaderboard)}
              className="p-2 bg-blue-800 bg-opacity-50 rounded-lg text-blue-300 hover:bg-blue-700 hover:bg-opacity-50 transition-colors"
            >
              {showLeaderboard ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto p-4 pt-16 lg:pt-6">
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-6">
          {/* القسم الرئيسي للمسابقة */}
          <div className="flex-1">
            {/* Header */}
            <div className="bg-gray-800 bg-opacity-80 backdrop-blur-md rounded-2xl shadow-2xl p-6 mb-6 border border-purple-500 border-opacity-30">
              <div className="flex items-center justify-between mb-5">
                <button
                  onClick={onBack}
                  className="p-2 hover:bg-blue-900 hover:bg-opacity-30 rounded-xl transition-colors text-blue-300 hover:text-purple-400 hover:shadow-lg"
                >
                  <ArrowLeft className="w-6 h-6" />
                </button>
                
                <div className="text-center flex-1 mx-4">
                  <h1 className="text-2xl font-bold text-white truncate">{quiz.title}</h1>
                  <p className="text-sm text-gray-300">السؤال {currentQuestionIndex + 1} من {questions.length}</p>
                </div>
                
                <div className="text-right">
                  <div className="text-sm text-gray-300">النقاط</div>
                  <div className="text-xl font-bold text-white flex items-center justify-end gap-1">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    {score}
                  </div>
                </div>
              </div>
              
              {/* Progress Bar */}
              <div className="w-full bg-gray-700 rounded-full h-2.5 mb-5">
                <div 
                  className="bg-gradient-to-r from-purple-600 to-blue-600 h-2.5 rounded-full transition-all duration-300 shadow-lg"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              
              {/* Timer */}
              <div className="flex items-center justify-center">
                <div className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold ${
                  timeLeft <= 5 ? 'bg-red-900 bg-opacity-60 text-red-200 animate-pulse' : 'bg-blue-900 bg-opacity-60 text-blue-200'
                } shadow-lg`}>
                  <Clock className="w-4 h-4" />
                  <span>{timeLeft} ثانية</span>
                </div>
              </div>
            </div>

            {/* Question */}
            <div className="bg-gray-800 bg-opacity-80 backdrop-blur-md rounded-2xl shadow-2xl p-6 md:p-7 mb-6 border border-purple-500 border-opacity-30">
              <div className="text-center mb-7">
                <h2 className="text-xl md:text-2xl font-bold text-white mb-5 leading-relaxed text-shadow-lg">
                  {currentQuestion.question}
                </h2>
                
                {(currentQuestion as any).imageUrl && (
                  <div className="mb-6">
                    <img 
                      src={(currentQuestion as any).imageUrl} 
                      alt="Question" 
                      className="max-w-full h-auto max-h-60 md:max-h-72 mx-auto rounded-xl shadow-2xl border border-gray-700"
                    />
                  </div>
                )}
              </div>
              
              {/* Answer Options */}
              <div className="grid grid-cols-1 gap-4 mb-6">
                {shuffledOptions.map((option, index) => {
                  const isSelected = selectedAnswer === option.originalIndex;
                  const isAnswered = answeredQuestions.has(currentQuestionIndex);
                  
                  return (
                    <button
                      key={index}
                      onClick={() => handleAnswerSelect(option.originalIndex)}
                      disabled={isAnswered || isSubmitting}
                      className={`p-5 rounded-xl border-2 transition-all text-right transform hover:scale-[1.02] ${
                        isSelected
                          ? 'border-blue-400 bg-blue-900 bg-opacity-40 text-white shadow-lg shadow-blue-500/30'
                          : 'border-gray-700 bg-gray-800 bg-opacity-70 hover:border-purple-500 hover:bg-purple-900 hover:bg-opacity-30 hover:shadow-lg hover:shadow-purple-500/10 text-gray-100'
                      } ${(isAnswered || isSubmitting) ? 'cursor-default' : 'cursor-pointer'}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-7 h-7 rounded-full border-2 flex items-center justify-center ${
                          isSelected 
                            ? 'border-blue-400 bg-blue-900 text-white'
                            : 'border-gray-600 bg-gray-800 text-gray-300'
                        }`}>
                          {isSelected && (
                            <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                          )}
                        </div>
                        <span className="text-right flex-1 text-lg font-medium">{option.text}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Feedback for answer */}
              {showAnswerFeedback && (
                <div className={`p-4 rounded-xl mb-4 text-center ${
                  showAnswerFeedback.isCorrect 
                    ? 'bg-green-900 bg-opacity-40 border border-green-600' 
                    : 'bg-red-900 bg-opacity-40 border border-red-600'
                }`}>
                  <div className="flex items-center justify-center gap-2">
                    {showAnswerFeedback.isCorrect ? (
                      <>
                        <CheckCircle className="w-6 h-6 text-green-400" />
                        <span className="text-green-300 font-bold">إجابة صحيحة!</span>
                        <span className="text-yellow-300 flex items-center gap-1">
                          +{showAnswerFeedback.points} <Zap className="w-4 h-4" />
                        </span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-6 h-6 text-red-400" />
                        <span className="text-red-300 font-bold">إجابة خاطئة</span>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-gray-800 bg-opacity-80 backdrop-blur-md rounded-xl shadow-lg p-4 text-center border border-green-600 border-opacity-40 hover:shadow-green-500/10 transition-all">
                <div className="text-xl font-bold text-green-400 flex items-center justify-center gap-1">
                  <CheckCircle className="w-5 h-5" />
                  {correctAnswers}
                </div>
                <div className="text-sm text-gray-300">صحيحة</div>
              </div>
              <div className="bg-gray-800 bg-opacity-80 backdrop-blur-md rounded-xl shadow-lg p-4 text-center border border-red-600 border-opacity-40 hover:shadow-red-500/10 transition-all">
                <div className="text-xl font-bold text-red-400 flex items-center justify-center gap-1">
                  <XCircle className="w-5 h-5" />
                  {currentQuestionIndex - correctAnswers}
                </div>
                <div className="text-sm text-gray-300">خاطئة</div>
              </div>
              <div className="bg-gray-800 bg-opacity-80 backdrop-blur-md rounded-xl shadow-lg p-4 text-center border border-blue-600 border-opacity-40 hover:shadow-blue-500/10 transition-all">
                <div className="text-xl font-bold text-blue-400 flex items-center justify-center gap-1">
                  <Target className="w-5 h-5" />
                  {currentQuestionIndex + 1}/{questions.length}
                </div>
                <div className="text-sm text-gray-300">مكتمل</div>
              </div>
            </div>
          </div>

          {/* الشريط الجانبي لأول 3 مراكز - للشاشات الكبيرة */}
          <div className="hidden lg:block w-80">
            <LeaderboardSection 
              top3Players={top3Players} 
              user={user} 
              userRank={userRank} 
              score={score} 
              leaderboard={leaderboard} 
            />
          </div>

          {/* الشريط الجانبي للشاشات الصغيرة (منبثق) */}
          {showLeaderboard && (
            <div className="lg:hidden fixed inset-0 bg-black bg-opacity-80 z-40 flex justify-end">
              <div className="bg-gray-800 bg-opacity-95 backdrop-blur-md w-4/5 max-w-sm h-full p-6 overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-yellow-400" />
                    المتصدرين
                  </h2>
                  <button
                    onClick={() => setShowLeaderboard(false)}
                    className="text-gray-300 hover:text-white p-1 hover:bg-gray-700 hover:bg-opacity-30 rounded-full"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
                <LeaderboardSection 
                  top3Players={top3Players} 
                  user={user} 
                  userRank={userRank} 
                  score={score} 
                  leaderboard={leaderboard} 
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// مكون منفصل للمتصدرين
function LeaderboardSection({ top3Players, user, userRank, score, leaderboard }: any) {
  return (
    <div className="bg-gray-800 bg-opacity-80 backdrop-blur-md rounded-2xl shadow-2xl p-6 sticky top-6 border border-purple-500 border-opacity-30">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Trophy className="w-5 h-5 text-yellow-400" />
          أفضل 3 متسابقين
        </h2>
        <div className="text-xs text-gray-400 flex items-center gap-1">
          <RefreshCw className="w-3 h-3 animate-spin" />
          <span>تحديث تلقائي</span>
        </div>
      </div>

      {top3Players.length > 0 ? (
        <div className="space-y-4">
          {top3Players.map((player: any, index: number) => {
            const isCurrentUser = player.userId === user._id;
            
            return (
              <div 
                key={player._id} 
                className={`p-4 rounded-xl border-2 transition-all transform hover:scale-[1.02] ${
                  isCurrentUser 
                    ? 'border-purple-500 bg-purple-900 bg-opacity-40 shadow-lg shadow-purple-500/20' 
                    : index === 0 
                      ? 'border-yellow-400 bg-yellow-900 bg-opacity-30' 
                      : index === 1 
                        ? 'border-gray-400 bg-gray-800 bg-opacity-60' 
                        : 'border-amber-600 bg-amber-900 bg-opacity-30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-gray-200">
                      {index === 0 ? <Crown className="w-5 h-5 text-yellow-400" /> : 
                       index === 1 ? <Medal className="w-5 h-5 text-gray-300" /> : 
                       <Award className="w-5 h-5 text-amber-500" />}
                    </div>
                    <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-700 to-blue-700 flex items-center justify-center overflow-hidden border border-gray-700 shadow-lg">
                      {player.userAvatar ? (
                        <img 
                          src={player.userAvatar} 
                          alt={player.userName} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="w-5 h-5 text-gray-300" />
                      )}
                    </div>
                    <div className="max-w-[120px]">
                      <h3 className="font-semibold text-white truncate">
                        {isCurrentUser ? 'أنت' : player.userName}
                      </h3>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-white flex items-center gap-1">
                      <Zap className="w-4 h-4 text-yellow-400" />
                      {player.score}
                    </div>
                    <div className="text-xs text-gray-300">نقطة</div>
                  </div>
                </div>
              </div>
            );
          })}
          
          {/* عرض ترتيب المستخدم الحالي */}
          {userRank > 0 && (
            <div className="mt-5 p-4 bg-blue-900 bg-opacity-30 rounded-xl border border-blue-500 border-opacity-40 hover:shadow-blue-500/10 transition-all">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white text-sm font-bold shadow-lg">
                    {userRank}
                  </div>
                  <span className="text-sm font-medium text-gray-300">ترتيبك الحالي</span>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-white flex items-center gap-1 justify-end">
                    <Zap className="w-4 h-4 text-yellow-400" />
                    {score}
                  </div>
                  <div className="text-xs text-gray-300">نقطة</div>
                </div>
              </div>
              
              {userRank > 3 && (
                <div className="mt-3 text-sm text-gray-400 bg-gray-800 bg-opacity-60 p-2 rounded-lg border border-gray-700">
                  أنت متقدم على {leaderboard.length - userRank} متسابق
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-6 text-gray-400">
          <div className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-3 border border-gray-700">
            <Trophy className="w-6 h-6 text-gray-500" />
          </div>
          <p className="text-sm">لا توجد نتائج بعد</p>
        </div>
      )}
    </div>
  );
}