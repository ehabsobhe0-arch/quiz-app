import React, { useState, useEffect } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { ArrowLeft, Crown, Trophy, Medal, Award, Clock, UserCheck, BarChart3, RefreshCw, Target, Calendar, User } from "lucide-react";

interface User {
  _id: string;
  name: string;
  avatarUrl?: string | null;
}

interface LiveDashboardProps {
  quizId: Id<"quizzes">;
  user: User;
  currentScore: number;
  onBack: () => void;
}

export default function LiveDashboard({ quizId, user, currentScore, onBack }: LiveDashboardProps) {
  const [lastUpdated, setLastUpdated] = useState(Date.now());
  const leaderboard = useQuery(api.attempts.getLeaderboard, { quizId }) || [];
  const quiz = useQuery(api.quizzes.getQuizById, { quizId });
  
  // تحديث البيانات كل 3 ثواني
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdated(Date.now());
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  // البحث عن ترتيب المستخدم الحالي
  const userRank = leaderboard.findIndex(entry => entry.userId === user._id) + 1;
  const userEntry = leaderboard.find(entry => entry.userId === user._id);

  // الحصول على أعلى 5 لاعبين
  const topPlayers = leaderboard.slice(0, 5);
  
  // الحصول على اللاعبين المجاورين للمستخدم
  const getSurroundingPlayers = () => {
    if (userRank <= 0) return [];
    
    const start = Math.max(0, userRank - 2);
    const end = Math.min(leaderboard.length, userRank + 1);
    
    return leaderboard.slice(start, end);
  };

  const surroundingPlayers = getSurroundingPlayers();

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('ar-EG');
  };

  const formatDate = (timestamp: any) => {
    if (!timestamp) return "غير محدد";
    return new Date(timestamp).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div 
      className="min-h-screen p-3 bg-gradient-to-b from-navy-50 to-navy-100"
      style={{ fontFamily: "'Cairo', 'Noto Sans Arabic', sans-serif" }}
    >
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-2xl p-4 mb-4 border border-gold-300/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={onBack}
                className="p-1 md:p-2 hover:bg-navy-50 rounded-lg transition-colors text-navy-700 hover:text-navy-900"
              >
                <ArrowLeft className="w-5 h-5 md:w-6 md:h-6" />
              </button>
              <div>
                <h1 className="text-lg md:text-xl font-bold text-navy-800">لوحة المتصدرين المباشرة</h1>
                <p className="text-xs md:text-sm text-navy-600 flex items-center gap-1">
                  <RefreshCw className="w-3 h-3" />
                  آخر تحديث: {formatTime(lastUpdated)}
                </p>
              </div>
            </div>
            
            <div className="text-center">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-r from-gold-500 to-gold-600 rounded-full flex items-center justify-center shadow-md">
                <Trophy className="w-5 h-5 md:w-6 md:h-6 text-white" />
              </div>
            </div>
          </div>

          {/* تاريخ انتهاء المسابقة */}
          {quiz && (
            <div className="mt-3 pt-3 border-t border-navy-200 flex items-center justify-center gap-2">
              <Calendar className="w-4 h-4 text-gold-600" />
              <span className="text-xs text-navy-600">
                تاريخ انتهاء المسابقة: {formatDate(quiz.endDate)}
              </span>
            </div>
          )}
        </div>

        {/* User Current Status */}
        <div className="bg-white rounded-2xl shadow-2xl p-4 mb-4 border border-gold-300/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r from-navy-600 to-navy-700 flex items-center justify-center shadow-md border-2 border-gold-400 overflow-hidden">
                {user.avatarUrl ? (
                  <img 
                    src={user.avatarUrl} 
                    alt={user.name} 
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-navy-600 flex items-center justify-center">
                    <User className="w-6 h-6 text-white" />
                  </div>
                )}
              </div>
              <div>
                <h2 className="text-sm md:text-base font-bold text-navy-800">{user.name}</h2>
                <p className="text-xs text-navy-600">رقمك في المسابقة</p>
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-gold-600">{userRank > 0 ? userRank : '--'}</div>
              <div className="text-xs text-navy-600">الترتيب</div>
            </div>
            
            <div className="text-center">
              <div className="text-xl md:text-2xl font-bold text-navy-700">{currentScore}</div>
              <div className="text-xs text-navy-600">النقاط</div>
            </div>
          </div>
        </div>

        {/* Top Players */}
        {topPlayers.length > 0 && (
          <div className="bg-white rounded-2xl shadow-2xl p-4 md:p-6 mb-4 border border-gold-300/30">
            <h2 className="text-lg md:text-xl font-bold text-navy-800 text-center mb-6 flex items-center justify-center gap-2">
              <Crown className="w-5 h-5 text-gold-600" />
              أفضل 5 متسابقين
            </h2>
            
            <div className="space-y-3">
              {topPlayers.map((player, index) => (
                <div 
                  key={player._id} 
                  className={`p-3 rounded-xl flex items-center justify-between transition-all duration-200 hover:shadow-md ${
                    index === 0 ? 'bg-gold-50 border border-gold-200' :
                    index === 1 ? 'bg-silver-50 border border-silver-200' :
                    index === 2 ? 'bg-bronze-50 border border-bronze-200' : 'bg-navy-50 border border-navy-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-md ${
                      index === 0 ? 'bg-gradient-to-r from-gold-500 to-gold-600' :
                      index === 1 ? 'bg-gradient-to-r from-silver-400 to-silver-500' :
                      index === 2 ? 'bg-gradient-to-r from-bronze-500 to-bronze-600' : 'bg-gradient-to-r from-navy-500 to-navy-600'
                    }`}>
                      {index === 0 ? <Crown className="w-4 h-4" /> : 
                       index === 1 ? <Medal className="w-4 h-4" /> : 
                       index === 2 ? <Award className="w-4 h-4" /> : index + 1}
                    </div>
                    
                    <div className="w-10 h-10 rounded-full bg-navy-200 flex items-center justify-center overflow-hidden shadow-sm border border-navy-100">
                      {player.userAvatar ? (
                        <img 
                          src={player.userAvatar} 
                          alt={player.userName} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-navy-300 flex items-center justify-center">
                          <User className="w-5 h-5 text-navy-700" />
                        </div>
                      )}
                    </div>
                    
                    <div className="max-w-[120px] md:max-w-[150px]">
                      <h3 className="font-semibold text-xs md:text-sm text-navy-800 truncate flex items-center gap-1">
                        {player.userName}
                        {player.userId === user._id && (
                          <span className="bg-navy-700 text-white text-xs font-semibold px-1.5 py-0.5 rounded-lg">
                            أنت
                          </span>
                        )}
                      </h3>
                      {player.submittedAt && (
                        <p className="text-xs text-navy-500 mt-1">
                          سلم في: {formatDate(player.submittedAt)}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-sm md:text-base font-bold text-navy-800">{player.score}</div>
                    <div className="text-xs text-navy-600">نقطة</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Surrounding Players */}
        {surroundingPlayers.length > 0 && userRank > 5 && (
          <div className="bg-white rounded-2xl shadow-2xl p-4 mb-4 border border-gold-300/30">
            <h2 className="text-base md:text-lg font-bold text-navy-800 text-center mb-4 flex items-center justify-center gap-2">
              <Target className="w-4 h-4 text-gold-600" />
              المتسابقون حولك
            </h2>
            
            <div className="space-y-2">
              {surroundingPlayers.map((player, index) => {
                const rank = leaderboard.findIndex(entry => entry._id === player._id) + 1;
                const isCurrentUser = player.userId === user._id;
                
                return (
                  <div 
                    key={player._id} 
                    className={`p-3 rounded-lg flex items-center justify-between transition-all duration-200 hover:bg-navy-50 ${
                      isCurrentUser ? 'bg-gradient-to-r from-navy-50 to-navy-100 border-r-4 border-gold-500' : 'bg-navy-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-navy-600 flex items-center justify-center text-xs font-bold text-white shadow-sm">
                        {rank}
                      </div>
                      
                      <div className="w-8 h-8 rounded-full bg-navy-200 flex items-center justify-center overflow-hidden shadow-sm border border-navy-100">
                        {player.userAvatar ? (
                          <img 
                            src={player.userAvatar} 
                            alt={player.userName} 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-navy-300 flex items-center justify-center">
                            <User className="w-4 h-4 text-navy-700" />
                          </div>
                        )}
                      </div>
                      
                      <div className="max-w-[100px] md:max-w-[130px]">
                        <h3 className="font-medium text-xs text-navy-800 truncate">
                          {isCurrentUser ? 'أنت' : player.userName}
                        </h3>
                        {player.submittedAt && (
                          <p className="text-xs text-navy-500 mt-1 truncate">
                            {formatDate(player.submittedAt)}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-xs font-bold text-navy-800">{player.score}</div>
                      <div className="text-xs text-navy-600">نقطة</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Progress Comparison */}
        {userEntry && (
          <div className="bg-white rounded-2xl shadow-2xl p-4 border border-gold-300/30">
            <h2 className="text-base md:text-lg font-bold text-navy-800 text-center mb-4 flex items-center justify-center gap-2">
              <BarChart3 className="w-4 h-4 text-gold-600" />
              مقارنة الأداء
            </h2>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-navy-50 rounded-xl p-3 text-center border border-navy-200 transition-all duration-200 hover:shadow-md">
                <div className="text-lg font-bold text-navy-700">{userEntry.correctAnswers}</div>
                <div className="text-xs text-navy-600 flex items-center justify-center gap-1">
                  <UserCheck className="w-3 h-3" />
                  إجابات صحيحة
                </div>
              </div>
              
              <div className="bg-gold-50 rounded-xl p-3 text-center border border-gold-200 transition-all duration-200 hover:shadow-md">
                <div className="text-lg font-bold text-navy-700">
                  {userEntry.totalQuestions > 0 
                    ? Math.round((userEntry.correctAnswers / userEntry.totalQuestions) * 100) 
                    : 0}%
                </div>
                <div className="text-xs text-navy-600">نسبة النجاح</div>
              </div>
              
              <div className="bg-silver-50 rounded-xl p-3 text-center border border-silver-200 transition-all duration-200 hover:shadow-md">
                <div className="text-lg font-bold text-navy-700">
                  {Math.round(userEntry.timeSpent / 1000)}s
                </div>
                <div className="text-xs text-navy-600 flex items-center justify-center gap-1">
                  <Clock className="w-3 h-3" />
                  الوقت المستغرق
                </div>
              </div>
              
              <div className="bg-bronze-50 rounded-xl p-3 text-center border border-bronze-200 transition-all duration-200 hover:shadow-md">
                <div className="text-lg font-bold text-navy-700">
                  {userEntry.totalQuestions > 0 
                    ? Math.round(userEntry.timeSpent / userEntry.totalQuestions / 1000) 
                    : 0}s
                </div>
                <div className="text-xs text-navy-600">متوسط الوقت/سؤال</div>
              </div>
            </div>

            {/* تاريخ تسليم المستخدم */}
            {userEntry.submittedAt && (
              <div className="mt-4 pt-4 border-t border-navy-200 text-center">
                <div className="flex items-center justify-center gap-2">
                  <Calendar className="w-4 h-4 text-gold-600" />
                  <span className="text-sm text-navy-700">
                    تاريخ تسليمك: {formatDate(userEntry.submittedAt)}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {leaderboard.length === 0 && (
          <div className="bg-white rounded-2xl shadow-2xl p-8 text-center border border-gold-300/30">
            <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-3 border border-navy-200">
              <Trophy className="w-6 h-6 text-navy-400" />
            </div>
            <h3 className="text-base md:text-lg font-semibold text-navy-800 mb-2">لا توجد نتائج بعد</h3>
            <p className="text-sm text-navy-600">لم يشارك أحد في هذه المسابقة بعد</p>
          </div>
        )}
      </div>

      {/* إضافة أنماط مخصصة للخطوط والألوان */}
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
          @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@400;600;700&display=swap');
          
          :root {
            --color-navy-900: #0f172a;
            --color-navy-800: #1e293b;
            --color-navy-700: #334155;
            --color-navy-600: #475569;
            --color-navy-500: #64748b;
            --color-navy-400: #94a3b8;
            --color-navy-300: #cbd5e1;
            --color-navy-200: #e2e8f0;
            --color-navy-100: #f1f5f9;
            --color-navy-50: #f8fafc;
            
            --color-gold-900: #713f12;
            --color-gold-800: #854d0e;
            --color-gold-700: #a16207;
            --color-gold-600: #ca8a04;
            --color-gold-500: #eab308;
            --color-gold-400: #facc15;
            --color-gold-300: #fde047;
            --color-gold-200: #fef08a;
            --color-gold-100: #fef9c3;
            --color-gold-50: #fefce8;
            
            --color-silver-600: #52525b;
            --color-silver-500: #71717a;
            --color-silver-400: #a1a1aa;
            --color-silver-300: #d4d4d8;
            --color-silver-200: #e4e4e7;
            --color-silver-100: #f4f4f5;
            --color-silver-50: #fafafa;
            
            --color-bronze-600: #78350f;
            --color-bronze-500: #92400e;
            --color-bronze-400: #b45309;
            --color-bronze-300: #d97706;
            --color-bronze-200: #f59e0b;
            --color-bronze-100: #fde68a;
            --color-bronze-50: #fffbeb;
          }
          
          .bg-navy-900 { background-color: var(--color-navy-900); }
          .bg-navy-800 { background-color: var(--color-navy-800); }
          .bg-navy-700 { background-color: var(--color-navy-700); }
          .bg-navy-600 { background-color: var(--color-navy-600); }
          .bg-navy-500 { background-color: var(--color-navy-500); }
          .bg-navy-400 { background-color: var(--color-navy-400); }
          .bg-navy-300 { background-color: var(--color-navy-300); }
          .bg-navy-200 { background-color: var(--color-navy-200); }
          .bg-navy-100 { background-color: var(--color-navy-100); }
          .bg-navy-50 { background-color: var(--color-navy-50); }
          
          .text-navy-900 { color: var(--color-navy-900); }
          .text-navy-800 { color: var(--color-navy-800); }
          .text-navy-700 { color: var(--color-navy-700); }
          .text-navy-600 { color: var(--color-navy-600); }
          .text-navy-500 { color: var(--color-navy-500); }
          .text-navy-400 { color: var(--color-navy-400); }
          .text-navy-300 { color: var(--color-navy-300); }
          .text-navy-200 { color: var(--color-navy-200); }
          .text-navy-100 { color: var(--color-navy-100); }
          .text-navy-50 { color: var(--color-navy-50); }
          
          .border-navy-900 { border-color: var(--color-navy-900); }
          .border-navy-800 { border-color: var(--color-navy-800); }
          .border-navy-700 { border-color: var(--color-navy-700); }
          .border-navy-600 { border-color: var(--color-navy-600); }
          .border-navy-500 { border-color: var(--color-navy-500); }
          .border-navy-400 { border-color: var(--color-navy-400); }
          .border-navy-300 { border-color: var(--color-navy-300); }
          .border-navy-200 { border-color: var(--color-navy-200); }
          .border-navy-100 { border-color: var(--color-navy-100); }
          .border-navy-50 { border-color: var(--color-navy-50); }
          
          .bg-gold-900 { background-color: var(--color-gold-900); }
          .bg-gold-800 { background-color: var(--color-gold-800); }
          .bg-gold-700 { background-color: var(--color-gold-700); }
          .bg-gold-600 { background-color: var(--color-gold-600); }
          .bg-gold-500 { background-color: var(--color-gold-500); }
          .bg-gold-400 { background-color: var(--color-gold-400); }
          .bg-gold-300 { background-color: var(--color-gold-300); }
          .bg-gold-200 { background-color: var(--color-gold-200); }
          .bg-gold-100 { background-color: var(--color-gold-100); }
          .bg-gold-50 { background-color: var(--color-gold-50); }
          
          .text-gold-900 { color: var(--color-gold-900); }
          .text-gold-800 { color: var(--color-gold-800); }
          .text-gold-700 { color: var(--color-gold-700); }
          .text-gold-600 { color: var(--color-gold-600); }
          .text-gold-500 { color: var(--color-gold-500); }
          .text-gold-400 { color: var(--color-gold-400); }
          .text-gold-300 { color: var(--color-gold-300); }
          .text-gold-200 { color: var(--color-gold-200); }
          .text-gold-100 { color: var(--color-gold-100); }
          .text-gold-50 { color: var(--color-gold-50); }
          
          .border-gold-900 { border-color: var(--color-gold-900); }
          .border-gold-800 { border-color: var(--color-gold-800); }
          .border-gold-700 { border-color: var(--color-gold-700); }
          .border-gold-600 { border-color: var(--color-gold-600); }
          .border-gold-500 { border-color: var(--color-gold-500); }
          .border-gold-400 { border-color: var(--color-gold-400); }
          .border-gold-300 { border-color: var(--color-gold-300); }
          .border-gold-200 { border-color: var(--color-gold-200); }
          .border-gold-100 { border-color: var(--color-gold-100); }
          .border-gold-50 { border-color: var(--color-gold-50); }
          
          .bg-silver-600 { background-color: var(--color-silver-600); }
          .bg-silver-500 { background-color: var(--color-silver-500); }
          .bg-silver-400 { background-color: var(--color-silver-400); }
          .bg-silver-300 { background-color: var(--color-silver-300); }
          .bg-silver-200 { background-color: var(--color-silver-200); }
          .bg-silver-100 { background-color: var(--color-silver-100); }
          .bg-silver-50 { background-color: var(--color-silver-50); }
          
          .text-silver-600 { color: var(--color-silver-600); }
          .text-silver-500 { color: var(--color-silver-500); }
          .text-silver-400 { color: var(--color-silver-400); }
          .text-silver-300 { color: var(--color-silver-300); }
          .text-silver-200 { color: var(--color-silver-200); }
          .text-silver-100 { color: var(--color-silver-100); }
          .text-silver-50 { color: var(--color-silver-50); }
          
          .border-silver-600 { border-color: var(--color-silver-600); }
          .border-silver-500 { border-color: var(--color-silver-500); }
          .border-silver-400 { border-color: var(--color-silver-400); }
          .border-silver-300 { border-color: var(--color-silver-300); }
          .border-silver-200 { border-color: var(--color-silver-200); }
          .border-silver-100 { border-color: var(--color-silver-100); }
          .border-silver-50 { border-color: var(--color-silver-50); }
          
          .bg-bronze-600 { background-color: var(--color-bronze-600); }
          .bg-bronze-500 { background-color: var(--color-bronze-500); }
          .bg-bronze-400 { background-color: var(--color-bronze-400); }
          .bg-bronze-300 { background-color: var(--color-bronze-300); }
          .bg-bronze-200 { background-color: var(--color-bronze-200); }
          .bg-bronze-100 { background-color: var(--color-bronze-100); }
          .bg-bronze-50 { background-color: var(--color-bronze-50); }
          
          .text-bronze-600 { color: var(--color-bronze-600); }
          .text-bronze-500 { color: var(--color-bronze-500); }
          .text-bronze-400 { color: var(--color-bronze-400); }
          .text-bronze-300 { color: var(--color-bronze-300); }
          .text-bronze-200 { color: var(--color-bronze-200); }
          .text-bronze-100 { color: var(--color-bronze-100); }
          .text-bronze-50 { color: var(--color-bronze-50); }
          
          .border-bronze-600 { border-color: var(--color-bronze-600); }
          .border-bronze-500 { border-color: var(--color-bronze-500); }
          .border-bronze-400 { border-color: var(--color-bronze-400); }
          .border-bronze-300 { border-color: var(--color-bronze-300); }
          .border-bronze-200 { border-color: var(--color-bronze-200); }
          .border-bronze-100 { border-color: var(--color-bronze-100); }
          .border-bronze-50 { border-color: var(--color-bronze-50); }
        `}
      </style>
    </div>
  );
}