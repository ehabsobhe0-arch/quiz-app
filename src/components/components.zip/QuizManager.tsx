import React, { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";
import { 
  Plus, 
  Play, 
  Square, 
  Trash2, 
  Edit, 
  ArrowLeft, 
  X, 
  CheckSquare, 
  Image, 
  Settings,
  BookOpen,
  List,
  BarChart3,
  Users,
  Award,
  Clock
} from "lucide-react";

interface User {
  _id: string;
  name: string;
  deviceFingerprint: string;
  isAdmin: boolean;
  isModerator: boolean;
}

interface QuizManagerProps {
  user: User;
}

export default function QuizManager({ user }: QuizManagerProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedQuiz, setSelectedQuiz] = useState<Id<"quizzes"> | null>(null);
  const [showQuestionForm, setShowQuestionForm] = useState(false);

  const quizzes = useQuery(api.quizzes.getAllQuizzes) || [];
  const questions = useQuery(api.questions.getQuizQuestions, 
    selectedQuiz ? { quizId: selectedQuiz } : "skip"
  ) || [];

  const createQuiz = useMutation(api.quizzes.createQuiz);
  const startQuiz = useMutation(api.quizzes.startQuiz);
  const stopQuiz = useMutation(api.quizzes.stopQuiz);
  const deleteQuiz = useMutation(api.quizzes.deleteQuiz);
  const addQuestion = useMutation(api.questions.addQuestion);
  const deleteQuestion = useMutation(api.questions.deleteQuestion);
  const generateUploadUrl = useMutation(api.users.generateUploadUrl);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    maxAttempts: 3,
    shuffleQuestions: true,
    shuffleAnswers: true,
    image: null as File | null,
  });

  const [questionData, setQuestionData] = useState({
    question: "",
    type: "multiple_choice" as "multiple_choice" | "true_false",
    options: ["", "", "", ""],
    correctAnswer: 0,
    image: null as File | null,
  });

  const handleCreateQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      toast.error("يرجى إدخال عنوان المسابقة");
      return;
    }

    try {
      let imageId = undefined;
      if (formData.image) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": formData.image.type },
          body: formData.image,
        });
        
        if (result.ok) {
          const { storageId } = await result.json();
          imageId = storageId;
        }
      }

      await createQuiz({
        title: formData.title,
        description: formData.description || undefined,
        image: imageId,
        maxAttempts: formData.maxAttempts,
        shuffleQuestions: formData.shuffleQuestions,
        shuffleAnswers: formData.shuffleAnswers,
        creatorFingerprint: user.deviceFingerprint,
      });

      toast.success("تم إنشاء المسابقة بنجاح");
      setShowCreateForm(false);
      setFormData({
        title: "",
        description: "",
        maxAttempts: 3,
        shuffleQuestions: true,
        shuffleAnswers: true,
        image: null,
      });
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إنشاء المسابقة");
    }
  };

  const handleAddQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionData.question.trim()) {
      toast.error("يرجى إدخال نص السؤال");
      return;
    }

    if (questionData.type === "multiple_choice") {
      const validOptions = questionData.options.filter(opt => opt.trim());
      if (validOptions.length < 2) {
        toast.error("يجب إدخال خيارين على الأقل");
        return;
      }
    }

    try {
      let imageId = undefined;
      if (questionData.image) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": questionData.image.type },
          body: questionData.image,
        });
        
        if (result.ok) {
          const { storageId } = await result.json();
          imageId = storageId;
        }
      }

      const options = questionData.type === "true_false" 
        ? ["صحيح", "خطأ"]
        : questionData.options.filter(opt => opt.trim());

      await addQuestion({
        quizId: selectedQuiz!,
        question: questionData.question,
        type: questionData.type,
        options,
        correctAnswer: questionData.correctAnswer,
        image: imageId,
        userFingerprint: user.deviceFingerprint,
      });

      toast.success("تم إضافة السؤال بنجاح");
      setShowQuestionForm(false);
      setQuestionData({
        question: "",
        type: "multiple_choice",
        options: ["", "", "", ""],
        correctAnswer: 0,
        image: null,
      });
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إضافة السؤال");
    }
  };

  const handleStartQuiz = async (quizId: Id<"quizzes">) => {
    try {
      await startQuiz({ quizId, userFingerprint: user.deviceFingerprint });
      toast.success("تم بدء المسابقة");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء بدء المسابقة");
    }
  };

  const handleStopQuiz = async (quizId: Id<"quizzes">) => {
    try {
      await stopQuiz({ quizId, userFingerprint: user.deviceFingerprint });
      toast.success("تم إيقاف المسابقة");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إيقاف المسابقة");
    }
  };

  const handleDeleteQuiz = async (quizId: Id<"quizzes">) => {
    if (!confirm("هل أنت متأكد من حذف هذه المسابقة؟ سيتم حذف جميع الأسئلة والنتائج المرتبطة بها.")) {
      return;
    }

    try {
      await deleteQuiz({ quizId, userFingerprint: user.deviceFingerprint });
      toast.success("تم حذف المسابقة");
      if (selectedQuiz === quizId) {
        setSelectedQuiz(null);
      }
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء حذف المسابقة");
    }
  };

  const handleDeleteQuestion = async (questionId: Id<"questions">) => {
    if (!confirm("هل أنت متأكد من حذف هذا السؤال؟")) {
      return;
    }

    try {
      await deleteQuestion({ questionId, userFingerprint: user.deviceFingerprint });
      toast.success("تم حذف السؤال");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء حذف السؤال");
    }
  };

  if (selectedQuiz) {
    const quiz = quizzes.find(q => q._id === selectedQuiz);
    
    return (
      <div 
        className="min-h-screen p-4 bg-gradient-to-br from-blue-50 to-blue-100"
        style={{ fontFamily: "'Cairo', 'Noto Sans Arabic', sans-serif" }}
      >
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-2xl shadow-lg p-5 mb-5 border border-blue-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setSelectedQuiz(null)}
                  className="p-2 hover:bg-blue-50 rounded-xl transition-colors text-blue-700 hover:text-blue-900"
                >
                  <ArrowLeft className="w-6 h-6" />
                </button>
                <div>
                  <h1 className="text-2xl font-bold text-gray-800">إدارة المسابقة</h1>
                  <p className="text-sm text-gray-600">{quiz?.title}</p>
                </div>
              </div>
              
              <button
                onClick={() => setShowQuestionForm(true)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-all duration-200 shadow-md"
              >
                <Plus className="w-4 h-4" />
                إضافة سؤال
              </button>
            </div>
          </div>

          {/* Questions List */}
          <div className="space-y-4">
            {questions.map((question, index) => (
              <div key={question._id} className="bg-white rounded-2xl shadow-lg p-5 border border-gray-200">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2 py-1 rounded-lg">
                        السؤال {index + 1}
                      </span>
                      <span className="bg-yellow-100 text-yellow-800 text-xs font-semibold px-2 py-1 rounded-lg">
                        {question.type === "multiple_choice" ? "اختيار متعدد" : "صح/خطأ"}
                      </span>
                    </div>
                    
                    <h3 className="font-semibold text-gray-800 mb-3 text-lg">{question.question}</h3>
                    
                    {(question as any).imageUrl && (
                      <img src={(question as any).imageUrl} alt="Question" className="w-32 h-24 object-cover rounded-lg mb-3 border border-gray-300" />
                    )}
                    
                    <div className="space-y-2">
                      {question.options.map((option, optIndex) => (
                        <div key={optIndex} className={`p-3 rounded-lg ${
                          optIndex === question.correctAnswer 
                            ? 'bg-green-100 text-green-800 border border-green-300 font-semibold' 
                            : 'bg-gray-100 text-gray-700 border border-gray-200'
                        }`}>
                          <div className="flex items-center gap-2">
                            {optIndex === question.correctAnswer && <CheckSquare className="w-4 h-4" />}
                            <span>{option}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <button
                    onClick={() => handleDeleteQuestion(question._id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors ml-2"
                    title="حذف السؤال"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
            
            {questions.length === 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-8 text-center border border-gray-200">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-200">
                  <BookOpen className="w-8 h-8 text-blue-500" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">لا توجد أسئلة بعد</h3>
                <p className="text-gray-600">ابدأ بإضافة أول سؤال!</p>
              </div>
            )}
          </div>

          {/* Add Question Form */}
          {showQuestionForm && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto border border-blue-200">
                <div className="flex items-center justify-between mb-5">
                  <h3 className="text-lg font-bold text-gray-800">إضافة سؤال جديد</h3>
                  <button
                    onClick={() => setShowQuestionForm(false)}
                    className="p-1 text-gray-500 hover:text-gray-700 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleAddQuestion} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">نص السؤال *</label>
                    <textarea
                      value={questionData.question}
                      onChange={(e) => setQuestionData({...questionData, question: e.target.value})}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                      rows={3}
                      required
                      placeholder="أدخل نص السؤال..."
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">نوع السؤال</label>
                    <select
                      value={questionData.type}
                      onChange={(e) => setQuestionData({...questionData, type: e.target.value as any})}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    >
                      <option value="multiple_choice">اختيار من متعدد</option>
                      <option value="true_false">صح/خطأ</option>
                    </select>
                  </div>

                  {questionData.type === "multiple_choice" && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">الخيارات</label>
                      <div className="space-y-3">
                        {questionData.options.map((option, index) => (
                          <div key={index} className="flex items-center gap-3">
                            <input
                              type="radio"
                              name="correctAnswer"
                              checked={questionData.correctAnswer === index}
                              onChange={() => setQuestionData({...questionData, correctAnswer: index})}
                              className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                            />
                            <input
                              type="text"
                              value={option}
                              onChange={(e) => {
                                const newOptions = [...questionData.options];
                                newOptions[index] = e.target.value;
                                setQuestionData({...questionData, options: newOptions});
                              }}
                              className="flex-1 px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                              placeholder={`الخيار ${index + 1}`}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {questionData.type === "true_false" && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">الإجابة الصحيحة</label>
                      <div className="flex gap-4">
                        <label className="flex items-center text-sm cursor-pointer">
                          <input
                            type="radio"
                            name="correctAnswer"
                            checked={questionData.correctAnswer === 0}
                            onChange={() => setQuestionData({...questionData, correctAnswer: 0})}
                            className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300 mr-2"
                          />
                          صحيح
                        </label>
                        <label className="flex items-center text-sm cursor-pointer">
                          <input
                            type="radio"
                            name="correctAnswer"
                            checked={questionData.correctAnswer === 1}
                            onChange={() => setQuestionData({...questionData, correctAnswer: 1})}
                            className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300 mr-2"
                          />
                          خطأ
                        </label>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">صورة السؤال (اختيارية)</label>
                    <div className="flex items-center gap-3">
                      <label className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg cursor-pointer transition-all duration-200 shadow-sm">
                        <Image className="w-4 h-4" />
                        اختر صورة
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => setQuestionData({...questionData, image: e.target.files?.[0] || null})}
                          className="hidden"
                        />
                      </label>
                      <span className="text-sm text-gray-600">
                        {questionData.image ? questionData.image.name : "لم يتم اختيار صورة"}
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <button
                      type="submit"
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg font-semibold transition-all duration-200 shadow-md"
                    >
                      إضافة السؤال
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowQuestionForm(false)}
                      className="flex-1 bg-gray-100 text-gray-700 py-3 px-4 rounded-lg font-semibold hover:bg-gray-200 transition-all duration-200"
                    >
                      إلغاء
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen p-4 bg-gradient-to-br from-blue-50 to-blue-100"
      style={{ fontFamily: "'Cairo', 'Noto Sans Arabic', sans-serif" }}
    >
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6 border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">إدارة المسابقات</h1>
              <p className="text-sm text-gray-600">إنشاء وإدارة مسابقاتك</p>
            </div>
            
            <button
              onClick={() => setShowCreateForm(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-all duration-200 shadow-md"
            >
              <Plus className="w-4 h-4" />
              إنشاء مسابقة جديدة
            </button>
          </div>
        </div>

        {/* Quizzes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {quizzes.map((quiz) => (
            <div key={quiz._id} className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-xl">
              {quiz.imageUrl && (
                <img src={quiz.imageUrl} alt={quiz.title} className="w-full h-40 object-cover" />
              )}
              <div className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-gray-800 truncate text-lg">{quiz.title}</h3>
                  {quiz.isActive && (
                    <span className="bg-green-100 text-green-800 text-xs font-semibold px-2 py-1 rounded-lg">
                      نشطة
                    </span>
                  )}
                </div>
                
                {quiz.description && (
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">{quiz.description}</p>
                )}
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-2">
                    <List className="w-4 h-4" />
                    <span>{quiz.questionCount} سؤال</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span className="truncate max-w-[100px]">{quiz.creatorName}</span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedQuiz(quiz._id)}
                    className="flex-1 bg-blue-100 text-blue-700 py-2 px-3 rounded-lg text-sm font-semibold hover:bg-blue-200 transition-all duration-200 flex items-center justify-center gap-1"
                  >
                    <Edit className="w-4 h-4" />
                    إدارة
                  </button>
                  
                  {quiz.isActive ? (
                    <button
                      onClick={() => handleStopQuiz(quiz._id)}
                      className="bg-red-100 text-red-700 py-2 px-3 rounded-lg text-sm font-semibold hover:bg-red-200 transition-all duration-200 flex items-center justify-center gap-1"
                      title="إيقاف المسابقة"
                    >
                      <Square className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => handleStartQuiz(quiz._id)}
                      className="bg-green-100 text-green-700 py-2 px-3 rounded-lg text-sm font-semibold hover:bg-green-200 transition-all duration-200 flex items-center justify-center gap-1"
                      title="بدء المسابقة"
                    >
                      <Play className="w-4 h-4" />
                    </button>
                  )}
                  
                  <button
                    onClick={() => handleDeleteQuiz(quiz._id)}
                    className="bg-red-100 text-red-700 py-2 px-3 rounded-lg text-sm font-semibold hover:bg-red-200 transition-all duration-200 flex items-center justify-center gap-1"
                    title="حذف المسابقة"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {quizzes.length === 0 && (
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center border border-gray-200">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-200">
              <BookOpen className="w-8 h-8 text-blue-500" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">لا توجد مسابقات</h3>
            <p className="text-gray-600">ابدأ بإنشاء أول مسابقة!</p>
          </div>
        )}

        {/* Create Quiz Form */}
        {showCreateForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl p-6 w-full max-w-md border border-blue-200">
              <div className="flex items-center justify-between mb-5">
                <h3 className="text-lg font-bold text-gray-800">إنشاء مسابقة جديدة</h3>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="p-1 text-gray-500 hover:text-gray-700 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateQuiz} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">عنوان المسابقة *</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    placeholder="أدخل عنوان المسابقة"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">الوصف</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    rows={3}
                    placeholder="أدخل وصفاً للمسابقة..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">عدد المحاولات المسموحة</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={formData.maxAttempts}
                    onChange={(e) => setFormData({...formData, maxAttempts: parseInt(e.target.value)})}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">صورة المسابقة (اختيارية)</label>
                  <div className="flex items-center gap-3">
                    <label className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg cursor-pointer transition-all duration-200 shadow-sm">
                      <Image className="w-4 h-4" />
                      اختر صورة
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => setFormData({...formData, image: e.target.files?.[0] || null})}
                        className="hidden"
                      />
                    </label>
                    <span className="text-sm text-gray-600">
                      {formData.image ? formData.image.name : "لم يتم اختيار صورة"}
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="flex items-center text-sm cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.shuffleQuestions}
                      onChange={(e) => setFormData({...formData, shuffleQuestions: e.target.checked})}
                      className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded mr-2"
                    />
                    خلط ترتيب الأسئلة
                  </label>
                  
                  <label className="flex items-center text-sm cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.shuffleAnswers}
                      onChange={(e) => setFormData({...formData, shuffleAnswers: e.target.checked})}
                      className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded mr-2"
                    />
                    خلط ترتيب الإجابات
                  </label>
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg font-semibold transition-all duration-200 shadow-md"
                  >
                    إنشاء المسابقة
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowCreateForm(false)}
                    className="flex-1 bg-gray-100 text-gray-700 py-3 px-4 rounded-lg font-semibold hover:bg-gray-200 transition-all duration-200"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}