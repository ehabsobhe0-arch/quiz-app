import React from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { Crown, Medal, Trophy, ArrowLeft, Award, Clock, UserCheck } from "lucide-react";

interface User {
  _id: string;
  name: string;
  avatarUrl?: string | null;
}

interface LeaderboardProps {
  quizId: Id<"quizzes">;
  user: User;
  onBack: () => void;
}

export default function Leaderboard({ quizId, user, onBack }: LeaderboardProps) {
  const leaderboard = useQuery(api.attempts.getLeaderboard, { quizId }) || [];
  const quiz = useQuery(api.quizzes.getActiveQuiz);

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return "from-gold-500 to-gold-600";
      case 2: return "from-silver-400 to-silver-500";
      case 3: return "from-bronze-500 to-bronze-600";
      default: return "from-navy-600 to-navy-700";
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-5 h-5 text-white" />;
      case 2: return <Medal className="w-5 h-5 text-white" />;
      case 3: return <Award className="w-5 h-5 text-white" />;
      default: return <span className="text-white font-bold">#{rank}</span>;
    }
  };

  return (
    <div 
      className="min-h-screen p-4 bg-gradient-to-br from-navy-900 via-navy-800 to-navy-900"
      style={{ fontFamily: "'Cairo', 'Noto Sans Arabic', sans-serif" }}
    >
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-2xl p-5 mb-5 border border-gold-300/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="p-2 hover:bg-navy-50 rounded-xl transition-colors text-navy-700 hover:text-navy-900"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-navy-800">لوحة المتصدرين</h1>
                <p className="text-sm text-navy-600">{quiz?.title}</p>
              </div>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-gold-500 to-gold-600 rounded-full flex items-center justify-center shadow-md">
                <Trophy className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Top 3 Podium */}
        {leaderboard.length > 0 && (
          <div className="bg-white rounded-2xl shadow-2xl p-5 md:p-6 mb-5 border border-gold-300/30">
            <h2 className="text-xl font-bold text-navy-800 text-center mb-6">أفضل 3 متسابقين</h2>
            
            <div className="flex items-end justify-center gap-5 md:gap-8">
              {/* Second Place */}
              {leaderboard[1] && (
                <div className="text-center flex-1 transform transition-all duration-300 hover:-translate-y-1">
                  <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-r from-silver-400 to-silver-500 flex items-center justify-center mx-auto mb-3 shadow-md border-2 border-silver-300">
                    {leaderboard[1].userAvatar ? (
                      <img 
                        src={leaderboard[1].userAvatar} 
                        alt={leaderboard[1].userName} 
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-white font-bold text-lg">
                        {leaderboard[1].userName.charAt(0)}
                      </span>
                    )}
                  </div>
                  <div className="bg-silver-50 rounded-xl p-3 h-24 md:h-28 flex flex-col justify-center border border-silver-200">
                    <div className="mb-1 flex justify-center">
                      <Medal className="w-6 h-6 md:w-7 md:h-7 text-silver-600" />
                    </div>
                    <div className="font-semibold text-sm md:text-base text-navy-800 truncate">{leaderboard[1].userName}</div>
                    <div className="text-sm text-navy-600">{leaderboard[1].score} نقطة</div>
                  </div>
                </div>
              )}

              {/* First Place */}
              {leaderboard[0] && (
                <div className="text-center flex-1 transform transition-all duration-300 hover:-translate-y-1">
                  <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-r from-gold-500 to-gold-600 flex items-center justify-center mx-auto mb-3 shadow-md border-2 border-gold-300">
                    {leaderboard[0].userAvatar ? (
                      <img 
                        src={leaderboard[0].userAvatar} 
                        alt={leaderboard[0].userName} 
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-white font-bold text-xl">
                        {leaderboard[0].userName.charAt(0)}
                      </span>
                    )}
                  </div>
                  <div className="bg-gold-50 rounded-xl p-3 h-28 md:h-32 flex flex-col justify-center border border-gold-200">
                    <div className="mb-1 flex justify-center">
                      <Crown className="w-7 h-7 md:w-8 md:h-8 text-gold-600" />
                    </div>
                    <div className="font-bold text-base md:text-lg text-navy-800 truncate">{leaderboard[0].userName}</div>
                    <div className="text-sm text-navy-600">{leaderboard[0].score} نقطة</div>
                    <div className="text-xs text-navy-500 hidden md:block mt-1">
                      <UserCheck className="w-3 h-3 inline mr-1" />
                      {leaderboard[0].correctAnswers}/{leaderboard[0].totalQuestions} صحيح
                    </div>
                  </div>
                </div>
              )}

              {/* Third Place */}
              {leaderboard[2] && (
                <div className="text-center flex-1 transform transition-all duration-300 hover:-translate-y-1">
                  <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-r from-bronze-500 to-bronze-600 flex items-center justify-center mx-auto mb-3 shadow-md border-2 border-bronze-300">
                    {leaderboard[2].userAvatar ? (
                      <img 
                        src={leaderboard[2].userAvatar} 
                        alt={leaderboard[2].userName} 
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-white font-bold text-lg">
                        {leaderboard[2].userName.charAt(0)}
                      </span>
                    )}
                  </div>
                  <div className="bg-bronze-50 rounded-xl p-3 h-24 md:h-28 flex flex-col justify-center border border-bronze-200">
                    <div className="mb-1 flex justify-center">
                      <Award className="w-6 h-6 md:w-7 md:h-7 text-bronze-600" />
                    </div>
                    <div className="font-semibold text-sm md:text-base text-navy-800 truncate">{leaderboard[2].userName}</div>
                    <div className="text-sm text-navy-600">{leaderboard[2].score} نقطة</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Full Leaderboard */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-gold-300/30">
          <div className="p-5 border-b border-navy-100 bg-gradient-to-r from-navy-50 to-navy-100">
            <h2 className="text-xl font-bold text-navy-800 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-gold-600" />
              جميع النتائج
            </h2>
          </div>
          
          <div className="divide-y divide-navy-100">
            {leaderboard.map((entry, index) => {
              const isCurrentUser = entry.userId === user._id;
              
              return (
                <div 
                  key={entry._id} 
                  className={`p-4 flex items-center justify-between transition-all duration-200 ${
                    isCurrentUser 
                      ? 'bg-gradient-to-r from-navy-50 to-navy-100 border-r-4 border-gold-500' 
                      : 'hover:bg-navy-50'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 md:w-12 md:h-12 rounded-full bg-gradient-to-r ${getRankColor(entry.rank)} flex items-center justify-center text-white shadow-md`}>
                      {getRankIcon(entry.rank)}
                    </div>
                    
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-navy-200 flex items-center justify-center overflow-hidden shadow-sm border border-navy-100">
                      {entry.userAvatar ? (
                        <img 
                          src={entry.userAvatar} 
                          alt={entry.userName} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-navy-700 font-semibold text-sm">
                          {entry.userName.charAt(0)}
                        </span>
                      )}
                    </div>
                    
                    <div className="max-w-[140px] md:max-w-none">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-sm md:text-base text-navy-800 truncate">{entry.userName}</h3>
                        {isCurrentUser && (
                          <span className="bg-navy-700 text-white text-xs font-semibold px-2 py-1 rounded-lg">
                            أنت
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-navy-600 flex items-center gap-1">
                        <UserCheck className="w-3 h-3" />
                        {entry.correctAnswers} من {entry.totalQuestions} صحيح
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-xl md:text-2xl font-bold text-navy-800">{entry.score}</div>
                    <div className="text-sm text-navy-600">نقطة</div>
                    <div className="text-xs text-navy-500 hidden md:flex items-center justify-end gap-1 mt-1">
                      <Clock className="w-3 h-3" />
                      {Math.round(entry.timeSpent / 1000)} ثانية
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          {leaderboard.length === 0 && (
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4 border border-navy-200">
                <Trophy className="w-8 h-8 text-navy-400" />
              </div>
              <h3 className="text-lg font-semibold text-navy-800 mb-2">لا توجد نتائج بعد</h3>
              <p className="text-base text-navy-600">لم يشارك أحد في هذه المسابقة بعد</p>
            </div>
          )}
        </div>
      </div>

      {/* إضافة أنماط مخصصة للخطوط والألوان */}
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
          @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@400;600;700&display=swap');
          
          :root {
            --color-navy-900: #0f172a;
            --color-navy-800: #1e293b;
            --color-navy-700: #334155;
            --color-navy-600: #475569;
            --color-navy-500: #64748b;
            --color-navy-400: #94a3b8;
            --color-navy-300: #cbd5e1;
            --color-navy-200: #e2e8f0;
            --color-navy-100: #f1f5f9;
            --color-navy-50: #f8fafc;
            
            --color-gold-900: #713f12;
            --color-gold-800: #854d0e;
            --color-gold-700: #a16207;
            --color-gold-600: #ca8a04;
            --color-gold-500: #eab308;
            --color-gold-400: #facc15;
            --color-gold-300: #fde047;
            --color-gold-200: #fef08a;
            --color-gold-100: #fef9c3;
            --color-gold-50: #fefce8;
            
            --color-silver-600: #52525b;
            --color-silver-500: #71717a;
            --color-silver-400: #a1a1aa;
            --color-silver-300: #d4d4d8;
            --color-silver-200: #e4e4e7;
            --color-silver-100: #f4f4f5;
            --color-silver-50: #fafafa;
            
            --color-bronze-600: #78350f;
            --color-bronze-500: #92400e;
            --color-bronze-400: #b45309;
            --color-bronze-300: #d97706;
            --color-bronze-200: #f59e0b;
            --color-bronze-100: #fde68a;
            --color-bronze-50: #fffbeb;
          }
          
          .bg-navy-900 { background-color: var(--color-navy-900); }
          .bg-navy-800 { background-color: var(--color-navy-800); }
          .bg-navy-700 { background-color: var(--color-navy-700); }
          .bg-navy-600 { background-color: var(--color-navy-600); }
          .bg-navy-500 { background-color: var(--color-navy-500); }
          .bg-navy-400 { background-color: var(--color-navy-400); }
          .bg-navy-300 { background-color: var(--color-navy-300); }
          .bg-navy-200 { background-color: var(--color-navy-200); }
          .bg-navy-100 { background-color: var(--color-navy-100); }
          .bg-navy-50 { background-color: var(--color-navy-50); }
          
          .text-navy-900 { color: var(--color-navy-900); }
          .text-navy-800 { color: var(--color-navy-800); }
          .text-navy-700 { color: var(--color-navy-700); }
          .text-navy-600 { color: var(--color-navy-600); }
          .text-navy-500 { color: var(--color-navy-500); }
          .text-navy-400 { color: var(--color-navy-400); }
          .text-navy-300 { color: var(--color-navy-300); }
          .text-navy-200 { color: var(--color-navy-200); }
          .text-navy-100 { color: var(--color-navy-100); }
          .text-navy-50 { color: var(--color-navy-50); }
          
          .border-navy-900 { border-color: var(--color-navy-900); }
          .border-navy-800 { border-color: var(--color-navy-800); }
          .border-navy-700 { border-color: var(--color-navy-700); }
          .border-navy-600 { border-color: var(--color-navy-600); }
          .border-navy-500 { border-color: var(--color-navy-500); }
          .border-navy-400 { border-color: var(--color-navy-400); }
          .border-navy-300 { border-color: var(--color-navy-300); }
          .border-navy-200 { border-color: var(--color-navy-200); }
          .border-navy-100 { border-color: var(--color-navy-100); }
          .border-navy-50 { border-color: var(--color-navy-50); }
          
          .bg-gold-900 { background-color: var(--color-gold-900); }
          .bg-gold-800 { background-color: var(--color-gold-800); }
          .bg-gold-700 { background-color: var(--color-gold-700); }
          .bg-gold-600 { background-color: var(--color-gold-600); }
          .bg-gold-500 { background-color: var(--color-gold-500); }
          .bg-gold-400 { background-color: var(--color-gold-400); }
          .bg-gold-300 { background-color: var(--color-gold-300); }
          .bg-gold-200 { background-color: var(--color-gold-200); }
          .bg-gold-100 { background-color: var(--color-gold-100); }
          .bg-gold-50 { background-color: var(--color-gold-50); }
          
          .text-gold-900 { color: var(--color-gold-900); }
          .text-gold-800 { color: var(--color-gold-800); }
          .text-gold-700 { color: var(--color-gold-700); }
          .text-gold-600 { color: var(--color-gold-600); }
          .text-gold-500 { color: var(--color-gold-500); }
          .text-gold-400 { color: var(--color-gold-400); }
          .text-gold-300 { color: var(--color-gold-300); }
          .text-gold-200 { color: var(--color-gold-200); }
          .text-gold-100 { color: var(--color-gold-100); }
          .text-gold-50 { color: var(--color-gold-50); }
          
          .border-gold-900 { border-color: var(--color-gold-900); }
          .border-gold-800 { border-color: var(--color-gold-800); }
          .border-gold-700 { border-color: var(--color-gold-700); }
          .border-gold-600 { border-color: var(--color-gold-600); }
          .border-gold-500 { border-color: var(--color-gold-500); }
          .border-gold-400 { border-color: var(--color-gold-400); }
          .border-gold-300 { border-color: var(--color-gold-300); }
          .border-gold-200 { border-color: var(--color-gold-200); }
          .border-gold-100 { border-color: var(--color-gold-100); }
          .border-gold-50 { border-color: var(--color-gold-50); }
          
          .bg-silver-600 { background-color: var(--color-silver-600); }
          .bg-silver-500 { background-color: var(--color-silver-500); }
          .bg-silver-400 { background-color: var(--color-silver-400); }
          .bg-silver-300 { background-color: var(--color-silver-300); }
          .bg-silver-200 { background-color: var(--color-silver-200); }
          .bg-silver-100 { background-color: var(--color-silver-100); }
          .bg-silver-50 { background-color: var(--color-silver-50); }
          
          .text-silver-600 { color: var(--color-silver-600); }
          .text-silver-500 { color: var(--color-silver-500); }
          .text-silver-400 { color: var(--color-silver-400); }
          .text-silver-300 { color: var(--color-silver-300); }
          .text-silver-200 { color: var(--color-silver-200); }
          .text-silver-100 { color: var(--color-silver-100); }
          .text-silver-50 { color: var(--color-silver-50); }
          
          .border-silver-600 { border-color: var(--color-silver-600); }
          .border-silver-500 { border-color: var(--color-silver-500); }
          .border-silver-400 { border-color: var(--color-silver-400); }
          .border-silver-300 { border-color: var(--color-silver-300); }
          .border-silver-200 { border-color: var(--color-silver-200); }
          .border-silver-100 { border-color: var(--color-silver-100); }
          .border-silver-50 { border-color: var(--color-silver-50); }
          
          .bg-bronze-600 { background-color: var(--color-bronze-600); }
          .bg-bronze-500 { background-color: var(--color-bronze-500); }
          .bg-bronze-400 { background-color: var(--color-bronze-400); }
          .bg-bronze-300 { background-color: var(--color-bronze-300); }
          .bg-bronze-200 { background-color: var(--color-bronze-200); }
          .bg-bronze-100 { background-color: var(--color-bronze-100); }
          .bg-bronze-50 { background-color: var(--color-bronze-50); }
          
          .text-bronze-600 { color: var(--color-bronze-600); }
          .text-bronze-500 { color: var(--color-bronze-500); }
          .text-bronze-400 { color: var(--color-bronze-400); }
          .text-bronze-300 { color: var(--color-bronze-300); }
          .text-bronze-200 { color: var(--color-bronze-200); }
          .text-bronze-100 { color: var(--color-bronze-100); }
          .text-bronze-50 { color: var(--color-bronze-50); }
          
          .border-bronze-600 { border-color: var(--color-bronze-600); }
          .border-bronze-500 { border-color: var(--color-bronze-500); }
          .border-bronze-400 { border-color: var(--color-bronze-400); }
          .border-bronze-300 { border-color: var(--color-bronze-300); }
          .border-bronze-200 { border-color: var(--color-bronze-200); }
          .border-bronze-100 { border-color: var(--color-bronze-100); }
          .border-bronze-50 { border-color: var(--color-bronze-50); }
        `}
      </style>
    </div>
  );
}