 import React, { useState } from "react";
import QuizManager from "./QuizManager";
import UserManager from "./UserManager";
import { Users, ListTodo } from "lucide-react";

interface User {
  _id: string;
  name: string;
  avatarUrl?: string | null;
  isAdmin: boolean;
  isModerator: boolean;
  deviceFingerprint: string;
}

interface AdminPanelProps {
  user: User;
  onBack: () => void;
}

export default function AdminPanel({ user, onBack }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<"quizzes" | "users">("quizzes");

  const tabs = [
    { id: "quizzes", name: "إدارة المسابقات", icon: <ListTodo size={18} /> },
    { id: "users", name: "إدارة المستخدمين", icon: <Users size={18} /> },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6 font-[Cairo]">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-md p-4 sm:p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <svg
                className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 19l-7-7 7-7"
                />
              </svg>
            </button>

            <div>
              <h1 className="text-lg sm:text-xl font-bold text-gray-900">
                لوحة الإدارة
              </h1>
              <p className="text-xs sm:text-sm text-gray-500">
                إدارة المسابقات والمستخدمين
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold text-sm sm:text-base">
              {user.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                user.name.charAt(0)
              )}
            </div>
            <span className="hidden sm:block text-sm font-medium text-gray-700">
              {user.name}
            </span>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-md">
          <div className="border-b border-gray-200 overflow-x-auto">
            <nav className="flex px-4 gap-6 min-w-max">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-3 px-2 flex items-center gap-2 font-medium text-sm border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? "border-indigo-600 text-indigo-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  {tab.icon}
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>

          {/* Content */}
          <div className="p-4 sm:p-6">
            {activeTab === "quizzes" && <QuizManager user={user} />}
            {activeTab === "users" && <UserManager user={user} />}
          </div>
        </div>
      </div>
    </div>
  );
}
